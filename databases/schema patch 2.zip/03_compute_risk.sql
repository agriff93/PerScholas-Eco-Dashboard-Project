-- =====================================================================
-- 03_compute_risk.sql
-- THE CONNECTION: spatially joins every parcel against the hazard layers
-- and writes one scored row per parcel into public.risk_analysis.
--
-- Re-runnable: ON CONFLICT refreshes existing rows. Run after loading
-- parcels (load_parcels_shp.py) AND the environmental layers.
--
-- Uses GIST indexes on both sides via ST_Intersects, so it scales to the
-- full ~1M parcels. For a county-by-county run, add a WHERE on p.county_name.
-- =====================================================================

INSERT INTO public.risk_analysis
    (parcel_id, county_name, parcel_no, flood_zone, flood_risk,
     in_wetland, in_habitat, overall_risk, compliance_status)
SELECT
    p.id,
    p.county_name,
    p.parcel_no,
    fz.fema_zone                              AS flood_zone,
    fema_zone_to_risk(fz.fema_zone)           AS flood_risk,
    (w.id  IS NOT NULL)                       AS in_wetland,
    (h.id  IS NOT NULL)                       AS in_habitat,
    -- overall = worst signal present
    CASE
        WHEN h.id IS NOT NULL
          OR fema_zone_to_risk(fz.fema_zone) = 'High'     THEN 'High'
        WHEN w.id IS NOT NULL
          OR fema_zone_to_risk(fz.fema_zone) = 'Moderate' THEN 'Moderate'
        ELSE 'Low'
    END                                       AS overall_risk,
    compute_compliance_status(
        fema_zone_to_risk(fz.fema_zone),
        w.id IS NOT NULL,
        h.id IS NOT NULL
    )                                         AS compliance_status
FROM "Parcels".parcels p
-- highest-risk flood zone touching the parcel (LATERAL keeps it to one row)
LEFT JOIN LATERAL (
    SELECT f.fema_zone
    FROM "Environmental_Layers".flood_zones f
    WHERE ST_Intersects(f.geom, p.geom)
    ORDER BY (fema_zone_to_risk(f.fema_zone) = 'High')     DESC,
             (fema_zone_to_risk(f.fema_zone) = 'Moderate') DESC
    LIMIT 1
) fz ON TRUE
-- does any wetland touch it?
LEFT JOIN LATERAL (
    SELECT 1 AS id
    FROM "Environmental_Layers".wetlands wl
    WHERE ST_Intersects(wl.geom, p.geom) LIMIT 1
) w ON TRUE
-- does any protected habitat touch it?
LEFT JOIN LATERAL (
    SELECT 1 AS id
    FROM "Environmental_Layers".protected_habitat ph
    WHERE ST_Intersects(ph.geom, p.geom) LIMIT 1
) h ON TRUE
ON CONFLICT (parcel_id) DO UPDATE SET
    flood_zone        = EXCLUDED.flood_zone,
    flood_risk        = EXCLUDED.flood_risk,
    in_wetland        = EXCLUDED.in_wetland,
    in_habitat        = EXCLUDED.in_habitat,
    overall_risk      = EXCLUDED.overall_risk,
    compliance_status = EXCLUDED.compliance_status,
    computed_at       = now();
