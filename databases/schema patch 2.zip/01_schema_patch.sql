-- =====================================================================
-- Parcels.parcels patch for shapefile loads (NC OneMap county downloads)
-- Safe to run against your existing schema — all statements idempotent.
--
-- WHY: your original dedup key was UNIQUE(county_name, source_oid), where
-- source_oid was the ArcGIS REST OBJECTID. The shapefile downloads do NOT
-- carry an OBJECTID, so we dedup on PARNO (the parcel number) instead.
-- =====================================================================

-- Add the real per-county identifier coming from the shapefile PARNO field.
ALTER TABLE "Parcels".parcels
    ADD COLUMN IF NOT EXISTS parcel_no TEXT;

-- Dedup on the key that actually exists in the data.
CREATE UNIQUE INDEX IF NOT EXISTS uq_parcel_county_parno
    ON "Parcels".parcels (county_name, parcel_no);

-- (Optional) if the old source_oid-based unique constraint exists and you
-- want it gone so it doesn't interfere, uncomment:
-- ALTER TABLE "Parcels".parcels DROP CONSTRAINT IF EXISTS uq_parcel_source;

-- Spatial + lookup indexes (no-ops if you already have them).
CREATE INDEX IF NOT EXISTS idx_parcels_geom   ON "Parcels".parcels USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_parcels_county ON "Parcels".parcels (county_name);
