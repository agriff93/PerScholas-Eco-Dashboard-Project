#!/usr/bin/env python3
"""
load_parcels_shp.py
Loads NC OneMap county parcel shapefiles into Parcels.parcels (PostGIS).

- Reads the *_poly.shp polygon layer for each county
- Reprojects NC State Plane ft (EPSG:2264) -> WGS84 (EPSG:4326)
- Forces MultiPolygon to match geometry(MultiPolygon, 4326)
- Dumps all 69 source attributes into the attributes JSONB column
- county_name <- CNTYNAME, parcel_no <- PARNO
- Idempotent: ON CONFLICT (county_name, parcel_no) DO NOTHING

Usage:
    python load_parcels_shp.py /path/to/extracted_shapefiles
Connection comes from env vars (or edit DB_* defaults below):
    PGHOST PGPORT PGDATABASE PGUSER PGPASSWORD
"""
import os, sys, glob, json, math, warnings
warnings.filterwarnings("ignore")  # silence harmless pyogrio dtype coercion notices
import geopandas as gpd
import pandas as pd
from shapely.geometry import MultiPolygon
import psycopg2
from psycopg2.extras import execute_values

DB = dict(
    host=os.getenv("PGHOST", "localhost"),
    port=os.getenv("PGPORT", "5432"),
    dbname=os.getenv("PGDATABASE", "eco_dashboard"),
    user=os.getenv("PGUSER", "postgres"),
    password=os.getenv("PGPASSWORD", ""),
)
BATCH = 5000

def jsonify(v):
    """Make a value JSON-safe."""
    if v is None:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    if isinstance(v, (pd.Timestamp,)):
        return None if pd.isna(v) else v.isoformat()
    try:
        if pd.isna(v):
            return None
    except (ValueError, TypeError):
        pass
    return v

def load_county(shp_path, conn):
    gdf = gpd.read_file(shp_path)
    gdf = gdf.to_crs(4326)  # reproject to WGS84

    # force everything to MultiPolygon (column type is MultiPolygon)
    gdf["geometry"] = gdf.geometry.apply(
        lambda g: g if g is None or g.geom_type == "MultiPolygon"
        else MultiPolygon([g]) if g.geom_type == "Polygon" else None
    )
    gdf = gdf[gdf.geometry.notna()]

    attr_cols = [c for c in gdf.columns if c != "geometry"]
    rows = []
    for _, r in gdf.iterrows():
        attrs = {c: jsonify(r[c]) for c in attr_cols}
        county = attrs.get("CNTYNAME")
        parno = attrs.get("PARNO")
        rows.append((parno, county, json.dumps(attrs), r.geometry.wkb_hex))

    sql = """
        INSERT INTO "Parcels".parcels (parcel_no, county_name, attributes, geom)
        VALUES %s
        ON CONFLICT (county_name, parcel_no) DO NOTHING
    """
    tmpl = "(%s,%s,%s,ST_Multi(ST_GeomFromWKB(decode(%s,'hex'),4326)))"
    with conn.cursor() as cur:
        before = count(cur)
        for i in range(0, len(rows), BATCH):
            execute_values(cur, sql, rows[i:i+BATCH], template=tmpl, page_size=BATCH)
        conn.commit()
        after = count(cur)
    return len(rows), after - before

def count(cur):
    cur.execute('SELECT count(*) FROM "Parcels".parcels')
    return cur.fetchone()[0]

def main():
    data_dir = sys.argv[1] if len(sys.argv) > 1 else "."
    polys = sorted(glob.glob(os.path.join(data_dir, "**", "*_poly.shp"), recursive=True))
    if not polys:
        sys.exit(f"No *_poly.shp found under {data_dir}")
    conn = psycopg2.connect(**DB)
    grand = 0
    for shp in polys:
        read, inserted = load_county(shp, conn)
        name = os.path.basename(shp)
        print(f"  {name:45s} read={read:>7d}  inserted={inserted:>7d}")
        grand += inserted
    with conn.cursor() as cur:
        total = count(cur)
    print(f"\nTotal inserted this run: {grand}   |   Table total: {total}")
    conn.close()

if __name__ == "__main__":
    main()
