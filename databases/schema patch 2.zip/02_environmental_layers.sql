-- =====================================================================
-- 02_environmental_layers.sql
-- The hazard layers that parcels are scored against, plus the helper
-- functions that translate raw hazard attributes into risk levels.
-- Geometry is WGS84 (4326) to match Parcels.parcels.
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS postgis;
CREATE SCHEMA IF NOT EXISTS "Environmental_Layers";

-- FEMA flood hazard zones (from the NFHL service).
CREATE TABLE IF NOT EXISTS "Environmental_Layers".flood_zones (
    id         SERIAL PRIMARY KEY,
    fema_zone  TEXT,                       -- e.g. 'AE', 'X', 'VE', '0.2 PCT ANNUAL CHANCE'
    attributes JSONB,
    geom       geometry(MultiPolygon, 4326)
);
CREATE INDEX IF NOT EXISTS idx_flood_geom ON "Environmental_Layers".flood_zones USING GIST (geom);

-- National Wetlands Inventory.
CREATE TABLE IF NOT EXISTS "Environmental_Layers".wetlands (
    id         SERIAL PRIMARY KEY,
    wet_type   TEXT,
    attributes JSONB,
    geom       geometry(MultiPolygon, 4326)
);
CREATE INDEX IF NOT EXISTS idx_wet_geom ON "Environmental_Layers".wetlands USING GIST (geom);

-- USFWS protected / critical habitat.
CREATE TABLE IF NOT EXISTS "Environmental_Layers".protected_habitat (
    id         SERIAL PRIMARY KEY,
    species    TEXT,
    attributes JSONB,
    geom       geometry(MultiPolygon, 4326)
);
CREATE INDEX IF NOT EXISTS idx_hab_geom ON "Environmental_Layers".protected_habitat USING GIST (geom);

-- ---------------------------------------------------------------------
-- Risk-analysis output table (one row per parcel after scoring).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.risk_analysis (
    id                SERIAL PRIMARY KEY,
    parcel_id         INTEGER REFERENCES "Parcels".parcels(id) ON DELETE CASCADE,
    county_name       TEXT,
    parcel_no         TEXT,
    flood_zone        TEXT,
    flood_risk        TEXT,        -- High / Moderate / Low / Minimal
    in_wetland        BOOLEAN,
    in_habitat        BOOLEAN,
    overall_risk      TEXT,        -- High / Moderate / Low
    compliance_status TEXT,        -- Restricted / Review Required / Clear
    computed_at       TIMESTAMPTZ DEFAULT now(),
    UNIQUE (parcel_id)
);
CREATE INDEX IF NOT EXISTS idx_risk_parcel ON public.risk_analysis (parcel_id);

-- ---------------------------------------------------------------------
-- Helper: FEMA zone code -> flood risk level.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fema_zone_to_risk(zone TEXT)
RETURNS TEXT AS $$
BEGIN
    IF zone IS NULL THEN RETURN 'Minimal'; END IF;
    -- Special Flood Hazard Areas (1% annual chance) + coastal V zones
    IF zone ~* '^(A|AE|AO|AH|AR|A99|V|VE)$' THEN RETURN 'High'; END IF;
    -- 0.2% annual chance / shaded X
    IF zone ~* '0\.2|SHADED|^B$'           THEN RETURN 'Moderate'; END IF;
    -- Minimal-risk X / C / D
    IF zone ~* '^(X|C|D)$'                 THEN RETURN 'Low'; END IF;
    RETURN 'Minimal';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- ---------------------------------------------------------------------
-- Helper: roll hazard flags up into a compliance status.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION compute_compliance_status(
    flood_risk TEXT, in_wetland BOOLEAN, in_habitat BOOLEAN
) RETURNS TEXT AS $$
BEGIN
    IF in_habitat OR flood_risk = 'High' THEN RETURN 'Restricted'; END IF;
    IF in_wetland OR flood_risk = 'Moderate' THEN RETURN 'Review Required'; END IF;
    RETURN 'Clear';
END;
$$ LANGUAGE plpgsql IMMUTABLE;
